package com.dizzmusic.app

import android.Manifest
import android.content.ContentUris
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer

private val Bg = Color(0xFF080611)
private val Panel = Color(0xFF171126)
private val Neon = Color(0xFFB44CFF)
private val Cyan = Color(0xFF39E7FF)

data class Track(val id: Long, val title: String, val artist: String, val uri: Uri)

class MainActivity : ComponentActivity() {
    private var player: ExoPlayer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        player = ExoPlayer.Builder(this).build()
        setContent {
            DizzMusicApp(
                onLoadTracks = { loadTracks() },
                onPlay = { track -> player?.setMediaItem(MediaItem.fromUri(track.uri)); player?.prepare(); player?.play() },
                onToggle = { if (player?.isPlaying == true) player?.pause() else player?.play() }
            )
        }
    }

    private fun loadTracks(): List<Track> {
        val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST)
        val tracks = mutableListOf<Track>()
        contentResolver.query(collection, projection, "${MediaStore.Audio.Media.IS_MUSIC} != 0", null, "${MediaStore.Audio.Media.TITLE} ASC")?.use { c ->
            val idCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val titleCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artistCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            while (c.moveToNext()) {
                val id = c.getLong(idCol)
                tracks += Track(id, c.getString(titleCol) ?: "Без названия", c.getString(artistCol) ?: "Неизвестный исполнитель",
                    ContentUris.withAppendedId(collection, id))
            }
        }
        return tracks
    }

    override fun onDestroy() { player?.release(); player = null; super.onDestroy() }
}

@Composable
fun DizzMusicApp(onLoadTracks: () -> List<Track>, onPlay: (Track) -> Unit, onToggle: () -> Unit) {
    var tracks by remember { mutableStateOf(emptyList<Track>()) }
    var selected by remember { mutableStateOf<Track?>(null) }
    var hasPermission by remember { mutableStateOf(false) }
    val permission = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        hasPermission = granted
        if (granted) tracks = onLoadTracks()
    }
    MaterialTheme(colorScheme = darkColorScheme(background = Bg, surface = Panel, primary = Neon)) {
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF211039), Bg, Color(0xFF090D1B))))) {
            Column(Modifier.fillMaxSize().padding(20.dp)) {
                Text("DIZZ", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 5.sp)
                Text("MUSIC", color = Neon, fontSize = 30.sp, fontWeight = FontWeight.Black)
                Spacer(Modifier.height(18.dp))
                NeonVisualizer(Modifier.fillMaxWidth().height(110.dp))
                Spacer(Modifier.height(18.dp))
                Text("ТВОЯ МУЗЫКА", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                Text("${tracks.size} треков на устройстве", color = Color.LightGray, fontSize = 12.sp)
                Spacer(Modifier.height(12.dp))
                if (!hasPermission) {
                    Button(onClick = { launcher.launch(permission) }, colors = ButtonDefaults.buttonColors(containerColor = Neon)) {
                        Text("Найти музыку на телефоне", color = Color.White)
                    }
                } else if (tracks.isEmpty()) {
                    Text("Музыка не найдена. Добавь аудиофайлы на телефон.", color = Color.LightGray)
                } else {
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(tracks) { track ->
                            Card(
                                onClick = { selected = track; onPlay(track) },
                                colors = CardDefaults.cardColors(containerColor = Panel),
                                shape = RoundedCornerShape(16.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Box(Modifier.size(42.dp).background(Brush.linearGradient(listOf(Neon, Cyan)), CircleShape), contentAlignment = Alignment.Center) {
                                        Text("♫", color = Color.White, fontSize = 22.sp)
                                    }
                                    Spacer(Modifier.width(12.dp))
                                    Column(Modifier.weight(1f)) {
                                        Text(track.title, color = Color.White, fontWeight = FontWeight.SemiBold, maxLines = 1)
                                        Text(track.artist, color = Color.LightGray, fontSize = 12.sp, maxLines = 1)
                                    }
                                    Text("▶", color = Cyan)
                                }
                            }
                        }
                    }
                }
                Spacer(Modifier.weight(1f))
                Card(colors = CardDefaults.cardColors(containerColor = Color(0xCC211832)), shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(selected?.title ?: "Выбери трек", color = Color.White, fontWeight = FontWeight.Bold, maxLines = 1)
                            Text(selected?.artist ?: "DizzMusic • локальный плеер", color = Color.LightGray, fontSize = 12.sp)
                        }
                        Button(onClick = onToggle, colors = ButtonDefaults.buttonColors(containerColor = Neon)) { Text("Ⅱ / ▶") }
                    }
                }
                Spacer(Modifier.height(8.dp))
                Text("ПЛЕЕР • БИБЛИОТЕКА • ВИЗУАЛИЗАЦИЯ", color = Color(0xFF9C8DAF), fontSize = 9.sp, letterSpacing = 1.sp)
            }
        }
    }
}

@Composable
fun NeonVisualizer(modifier: Modifier = Modifier) {
    val transition = rememberInfiniteTransition(label = "visualizer")
    val phase by transition.animateFloat(0f, 1f, infiniteRepeatable(tween(1100), RepeatMode.Reverse), label = "phase")
    Canvas(modifier.background(Brush.horizontalGradient(listOf(Color(0x442D164A), Color(0x2239E7FF), Color(0x442D164A))))) {
        val count =  forty
        val barWidth = size.width / (count * 1.8f)
        repeat(count) { i ->
            val wave = kotlin.math.abs(kotlin.math.sin((i * 0.55f + phase * 3.2f).toDouble())).toFloat()
            val h = size.height * (0.18f + wave * 0.72f)
            val x = i * size.width / count + barWidth * 0.4f
            drawLine(Neon.copy(alpha = 0.55f + wave * 0.4f), Offset(x, (size.height-h)/2), Offset(x, (size.height+h)/2), strokeWidth = barWidth, cap = androidx.compose.ui.graphics.StrokeCap.Round)
        }
    }
}
private const val forty = 40
